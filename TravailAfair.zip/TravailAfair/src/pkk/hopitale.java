package pkk;

import java.util.List;
import java.util.Objects;

public class hopitale  implements Cloneable, Comparable<hopitale> {
	private String localisation;
	private double capacity ;
	private double NBrSpecialite ;
	private double Stock ;
	
	public hopitale(String localisation, double capacity , double NBrSpecialite, double NbrSpecialite) {
		super();
		this.localisation = localisation;
		this.capacity = capacity;
		this.NBrSpecialite = NBrSpecialite;
		this.Stock = Stock;
		
      }

	
	

	@Override
	public String toString() {
		return this.getClass().getSimpleName() +":"+" localisation=" + localisation + ", capacity=" + capacity + ", NBrSpecialite=" + NBrSpecialite + ", stock=" + Stock ;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		hopitale other = (hopitale) obj;
		return Double.doubleToLongBits(capacity) == Double.doubleToLongBits(other.capacity)
				&& Double.doubleToLongBits(NBrSpecialite) == Double.doubleToLongBits(other.NBrSpecialite)
				&& Objects.equals(localisation, other.localisation)
				&& Double.doubleToLongBits(Stock) == Double.doubleToLongBits(other.Stock);
	       			
	}

	@Override
	public hopitale clone()  {
	
		try {
			return (hopitale) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int compareTo(hopitale other) {
		// TODO Auto-generated method stub
		return this.localisation.compareTo(other.localisation);
	}

	public int compareTo(hopitaleRegionnal other) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static boolean remove(hopitale hop) {
		// TODO Auto-generated method stub
		return false;
	}




	public static List<hopitale> subList(int deb, int fin) {
		// TODO Auto-generated method stub
		return null;
	}
	
}  