package pkk;

import java.util.Objects;

public class hopitaleRegionnal extends hopitale {
	
	private String Materiel;
	
	
	
	public hopitaleRegionnal (String localisation, double capacity, double NBrSpecialite, double Stock ) {
		super( localisation, capacity, NBrSpecialite, Stock );
		this.Materiel = Materiel;
	}
	
	
	
	@Override
	public String toString() {
		return  super.toString() + " ,Materiel= " +  Materiel;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(!super.equals(obj)) return false;
		if(obj instanceof hopitaleRegionnal) {
			hopitaleRegionnal other = (hopitaleRegionnal) obj;
		return Objects.equals(hopitaleRegionnal, other.hopitaleRegionnal);
		
		}
		return false;
		
	}
	@Override
	public hopitaleRegionnal clone(){
		// TODO Auto-generated method stub
		return (hopitaleRegionnal) super.clone();
	}
	public int CompareTo(hopitaleRegionnal otherhopitalRegionnal) {

		if(otherhopitalRegionnal instanceof hopitaleRegionnal)
		{
			hopitaleRegionnal h = (hopitaleRegionnal)otherhopitaleRegionnal;
			return this.Materiel.compareTo(h.Materiel);
		}
	
		return super.CompareTo(otherhopitaleRegionnal);
		}
}


