package pkk;

import java.util.ArrayList;



public class Arrayhopitale {
	private ArrayList<hopitale>hopitale; 
	public Arrayvehicule() {
		
	}
	public void trier(Comparator<hopitale> mp) {
		Arrays.sort(vhopitale,mp);
	}
	
	public double calculerSalaire() {
		double cpt =0;
		for(hopitale veh :hopitale) {
			cpt+=veh.gethopitale();
			}
		return cpt;
	}
}