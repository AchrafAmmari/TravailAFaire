package pkk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import Pk1.Vehicule;


public class ListhopitaleRegionnale<Hopital> {
	private LinkedList<hopitaleRegionnal> hopitaleReginnale = new LinkedList<hopitaleRegionnal>();
	//a.	Codez une fonction Java qui permet d’alimenter la liste.
	  public void alimenter() {
	        hopitale.add(new Hopitale("Shikh Zayd", "Localisation", 300, "Est"));
	        hopitale.add(new Hopitale("Hopital Nord", "Adresse3", 150);
	        
	  }
	  
  
		//b.	Codez une fonction Java qui permet d’afficher la liste (ligne par ligne).
		public void Afficher() {
			for(hopitale h : hopitaleRegionnal) {
				System.out.println(h);
			}
		}
		//c.	Codez une fonction Java qui permet de parcourir (à l’aide d’un Iterateur) tous les éléments de la liste.
		public void AfficherIterator() {
			Iterator<hopitale> it = hopitale.iterator();
			while(it.hasNext()) {
				System.out.println(it.next());
			}
		}
		//e.	Codez une fonction Java qui permet de récupérer un élément 
		public hopitale recuperer(int pos) {
			if(pos>=0&&pos<vehicule.size())
				return hopitale.get(pos);
			else
				throw new IllegalArgumentException();
		}
		//f.	Codez une fonction Java qui permet de supprimer un élément.
		public boolean suprimer(hopitale hop) {
			return hopitale.remove(hop);
		}
		//g.	Codez une fonction Java qui permet de rechercher un élément.
		public boolean rechercher(hopitale hop) {
			return  hopitale.contains(hop);
		}
		//h.	Codez une fonction Java qui permet de trier la liste
		public void trier(Comparator<hopitale>cmp) {
			  Collections.sort(hopitale,cmp);
		}
		//i.	Codez une fonction Java qui permet de copier la liste dans un nouveau tableau.
		public ArrayList<hopitale> copier()
		{
			//return new ArrayList<employee>(employes)
			ArrayList<hopitale> list =new ArrayList<hopitale>();
			list.addAll(hopitale);
			return list;
		}
		//j.	Codez une fonction Java qui permet de mélanger les élément de la liste.
		public void melanger() {
		    Collections.shuffle(hopitale);
		}
		//k.	Codez une fonction Java qui permet d’inverser les éléments de la liste.
		public void reverser() {
		    Collections.reverse(hopitale);
		}
		//l.	Codez une fonction Java qui permet d’extraire une partie de la liste.
		public List<hopitale> sousList(int deb,int fin){
			if(deb>0&&deb<fin)
			return hopitale.subList(deb, fin);
			throw new IllegalArgumentException();
		}
		//m.	Codez une fonction Java qui permet de comparer deux listes.
		public boolean comparer(ArrayList<hopitale> list) {
			try {
				return hopitale.equals(list);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//n.	Codez une fonction Java d'échange de deux éléments dans une liste.
		public void echanger(int in1 , int in2)
		{
			Collections.swap(hopitale, in1, in2);
			

		}
		//o.	Codez une fonction Java qui permet de vider la liste.
		public void vider() {
			hopitale.clear();
		}
		//p.	Codez une fonction Java qui permet de tester que la liste est vide ou non.
		public boolean est vide() {
			return hopitale.isEmpty();
		}
